require 'lib/profiler.rb'
require 'app/tick.rb'
