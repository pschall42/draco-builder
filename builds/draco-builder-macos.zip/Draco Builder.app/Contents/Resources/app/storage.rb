# frozen_string_literal: true

module Storage
  class << self
    # aoh_2_hoa ≅ hoa_2_aoh
    # Array of Hashes -> Hash of Arrays
    # [ {a: 'a', b: 'b'}, {b: 5, c: 'c'}, {d: 4, e: 'e'}, {y: 'why', z: 'zed'} ]
    def aoh_2_hoa(aoh)
      keys = aoh.reduce([]){|acc, hash| acc |= hash.keys }
      values = aoh.reduce([]){|acc, hash| acc.size == 0 ? keys.map{|k| [hash[k]]} : acc.zip(hash.values_at(*keys)).map(&:flatten)}
      keys.zip(values).to_h
    end
    # Hash of Arrays -> Array of Hashes
    def hoa_2_aoh(hoa)
      hoa.reduce([]){|acc, (key, values)|
        values.each_with_index{|v, idx|
          acc_hash = acc[idx] || {}
          acc[idx] = acc_hash.merge({key => v}).compact
        }
        acc
      }
    end

    # # optimize_for_json ≅ deoptimize_from_json
    # def optimize_for_json(obj)
    #   case obj
    #   when Hash
    #     puts "HASH obj: #{obj.inspect}"
    #     partial_opt_hoa = obj.transform_values{|v| optimize_for_json(v)}
    #     puts "partial_opt_hoa: #{partial_opt_hoa.inspect}"
    #     all_arr_vals = partial_opt_hoa.all?{|_,v| v.is_a?(Array)}
    #     partial_opt_aoh = all_arr_vals ? self.hoa_2_aoh(partial_opt_hoa) : [partial_opt_hoa]
    #     puts "partial_opt_aoh: #{partial_opt_aoh.inspect}"
    #     hoa_json = partial_opt_hoa.to_json
    #     aoh_json = partial_opt_aoh.to_json
    #     # Prefer hash over arrays if equal
    #     if hoa_json.size <= aoh_json.size
    #       {hoa: partial_opt_hoa}
    #     else
    #       {aoh: partial_opt_aoh}
    #     end
    #   when Array
    #     puts "ARRAY obj: #{obj.inspect}"
    #     partial_opt_aoh = obj.map{|v| optimize_for_json(v)}
    #     puts "partial_opt_aoh: #{partial_opt_aoh.inspect}"
    #     partial_opt_hoa = self.aoh_2_hoa(partial_opt_aoh)
    #     puts "partial_opt_hoa: #{partial_opt_hoa.inspect}"
    #     hoa_json = partial_opt_hoa.to_json
    #     aoh_json = partial_opt_aoh.to_json
    #     # Prefer hash over arrays if equal
    #     if hoa_json.size <= aoh_json.size
    #       {hoa: partial_opt_hoa}
    #     else
    #       {aoh: partial_opt_aoh}
    #     end
    #   else
    #     obj
    #   end
    # end
    # # Always returns as hashes
    # def deoptimize_from_json(obj, type: nil)
    #   case type
    #   when :aoh
    #     hoa = self.aoh_2_hoa(obj)
    #     self.deoptimize_from_json(hoa)
    #   when :hoa
    #     self.deoptimize_from_json(obj)
    #   else # type is nil, so parse by obj
    #     case obj
    #     when Hash
    #       if obj[:aoh].present?
    #         self.deoptimize_from_json(obj[:aoh], type: :aoh)
    #       elsif obj[:hoa].present?
    #         self.deoptimize_from_json(obj[:hoa], type: :hoa)
    #       else
    #         obj.transform_values{|v| self.deoptimize_from_json(v)}
    #       end
    #     when Array
    #       obj.map{|v| self.deoptimize_from_json(v)}
    #     else
    #       obj
    #     end
    #   end
    # end
  end
end